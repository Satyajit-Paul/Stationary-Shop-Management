#ifndef OPTIONS_H
#define OPTIONS_H

#include <bits/stdc++.h>
#include "Seller_Copy.h"


class Options : public Seller_Copy
{
    public:
        Options();
        virtual ~Options();
        void Basic();
        void View();
        void Update();
        void Search_by_Name();
        void Search_by_Phone();
        void Search_by_Email();
        int Counter();
        ///vector <Seller_Copy> Search();

    protected:

    private:
};

#endif // OPTIONS_H
