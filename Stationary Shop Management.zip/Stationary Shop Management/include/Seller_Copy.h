#ifndef SELLER_COPY_H
#define SELLER_COPY_H

#include <bits/stdc++.h>
#include "Buyer_Copy.h"

using namespace std;

class Seller_Copy : public Buyer_Copy
{
    public:
        vector <Buyer_Copy> temp;

        Seller_Copy();
        Seller_Copy(int);
        virtual ~Seller_Copy();
        void set_n(int);
        void set_Buyer_Name(string);
        string get_Buyer_Name();
        void set_Mail(string);
        string get_Mail();
        void set_Phone(string);
        string get_Phone();
        void set_Address(string);
        void set_Total_Amount(double);
        void set_total();
        void Write_to_History();
        int get_Serial_Number();

        friend istream & operator >> (istream &, Seller_Copy &);
        friend ostream & operator << (ostream &, Seller_Copy &);

    protected:
        string Buyer_Name, Email, Phone, Address;
        int n;
        double Total_Amunt;


    private:
        ///int Serial_Number = 1;

};

#endif // SELLER_COPY_H
