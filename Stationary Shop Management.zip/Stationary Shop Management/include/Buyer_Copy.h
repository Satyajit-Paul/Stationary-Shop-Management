#ifndef BUYER_COPY_H
#define BUYER_COPY_H
#include <bits/stdc++.h>

using namespace std;

class Buyer_Copy
{
    public:
        Buyer_Copy();
        Buyer_Copy(string, string, string, int, double);
        virtual ~Buyer_Copy();
        void set_Product_Id(string);
        void set_Product_Name(string);
        void set_Brand(string);
        void set_Quantity(int);
        void set_Price(double);
        double get_total();
        void Write_to_List();
        void Write_to_List(ofstream &);

        friend istream & operator >> (istream &, Buyer_Copy &);
        friend ostream & operator << (ostream &, Buyer_Copy &);

    protected:
        string Product_Name, Product_Id, Brand;
        double Price, total;
        int No_of_Product;

    private:

};

#endif // BUYER_COPY_H
