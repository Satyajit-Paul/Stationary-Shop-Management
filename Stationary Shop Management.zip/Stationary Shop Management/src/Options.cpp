#include <bits/stdc++.h>
#include "Options.h"

int main();

Options :: Options()
{
    //ctor
}

Options :: ~Options()
{
    //dtor
}

int Options :: Counter()
{
    int count = 0;
    ifstream infile;
    infile.open("Seller_Copy.txt");
    string line;
    while(getline(infile, line))
    {
        if(line == "    ==== 0 ====    ")
        {
            count++;
        }
    }

    infile.close();

    return count;
}

void Options :: Basic()
{
    system("cls");
    cout << "      __________________________    " << endl;
    cout << "     |1.Search By Name of Buyer |   " << endl;
    cout << "      --------------------------    " << endl;

    cout << "      __________________________    " << endl;
    cout << "     |2.Search By Phone Number  |   " << endl;
    cout << "      --------------------------    " << endl;

    cout << "      __________________________    " << endl;
    cout << "     |3.Search By Email Address |   " << endl;
    cout << "      --------------------------    " << endl;

    cout << "      __________________________    " << endl;
    cout << "     |4.Main Menu               |   " << endl;
    cout << "      --------------------------    " << endl;

    cout << "      __________________________    " << endl;
    cout << "     |5.Exit                    |   " << endl;
    cout << "      --------------------------    " << endl;

    B:
    int Choise;
    cout << "Chose an Option: ";
    cin >> Choise;

    switch(Choise)
    {
    case 1:
        Search_by_Name();
        break;
    case 2:
        Search_by_Phone();
        break;
    case 3:
        Search_by_Email();
        break;
    case 4:
        return;
    ///break;
    case 5:
        exit(1);

    default:
        cout << "Wrong Selection !!!" << endl;
        goto B;
    }
}

/**
vector <Seller_Copy> Options :: Search()
{
    int n;
    n = Counter();
    ///int len = 0;
    vector <Seller_Copy> Vec;

    ifstream infile;
    infile.open("Seller_Copy.txt");
    string line, dummy, data1;
    double data2;
    int data3;

    while(infile)
    {
        Seller_Copy S;
        getline(infile, line);

        if(line == "    ==== 0 ====    ")
        {
            len++;
        }

        stringstream ss(line);
        ss >> dummy;

        if(dummy == "Name:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Buyer_Name(data1);
        }
        else if(dummy == "Phone:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Phone(data1);
        }
        else if(dummy == "Email:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Mail(data1);
        }
        else if(dummy == "Address:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Address(data1);
        }
        else if(dummy == "Product_Types:")
        {
            ss >> data3;
            ///cout << data3 << endl;
            S.set_n(data3);

            int x = data3;

            for(int i = 1; i <= x; i++)
            {
                string s1, s2, s3;
                int x;
                double y;

                getline(infile, line);
                stringstream sss1(line);
                sss1 >> dummy >> s1;
                ///B.set_Product_Id(data1);

                getline(infile, line);
                stringstream sss2(line);
                sss2 >> dummy >> s2;
                ///B.set_Product_Name(data1);

                getline(infile, line);
                stringstream sss3(line);
                sss3 >> dummy >> s3;
                ///B.set_Brand(data1);

                getline(infile, line);
                stringstream sss4(line);
                sss4 >> dummy >> x;
                ///B.set_Quantity(data3);

                getline(infile, line);
                stringstream sss5(line);
                sss5 >> dummy >> y;
                ///B.set_Price(data2);

                Buyer_Copy B(s1, s2, s3, x, y);

                ///cout << B << endl;

                S.temp.push_back(B);

            }

            getline(infile, line);
            stringstream ssss(line);
            ssss >> dummy >> data2;
            ///cout << data2 << endl;
            S.set_Total_Amount(data2);

        }

        Vec.push_back(S);
    }

    infile.close();

    for(int i = 0; i < n; i++)
    {
        cout << Vec[i] << endl;
    }

    return Vec;
}
**/

void Options :: Search_by_Name()
{
    system("PAUSE");
    system("cls");

    string Nam;
    cout << "Enter The Name You Want To Search: ";
    cin >> ws;
    getline(cin, Nam);

    int n;
    n = Counter();

    vector <Seller_Copy> Vec;

    ifstream infile;
    infile.open("Seller_Copy.txt");
    string line, dummy, data1;
    double data2;
    int data3;

    ///Seller_Copy S;

    while(infile)
    {
        Seller_Copy S;
        getline(infile, line);

        stringstream ss(line);
        ss >> dummy;

        if(dummy == "Name:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Buyer_Name(data1);
        }
        else if(dummy == "Phone:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Phone(data1);
        }
        else if(dummy == "Email:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Mail(data1);
        }
        else if(dummy == "Address:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Address(data1);
        }
        else if(dummy == "Product_Types:")
        {
            ss >> data3;
            ///cout << data3 << endl;
            S.set_n(data3);

            int x = data3;

            for(int i = 1; i <= x; i++)
            {
                string s1, s2, s3;
                int x;
                double y;

                getline(infile, line);
                stringstream sss1(line);
                sss1 >> dummy >> s1;
                ///B.set_Product_Id(data1);

                getline(infile, line);
                stringstream sss2(line);
                sss2 >> dummy >> s2;
                ///B.set_Product_Name(data1);

                getline(infile, line);
                stringstream sss3(line);
                sss3 >> dummy >> s3;
                ///B.set_Brand(data1);

                getline(infile, line);
                stringstream sss4(line);
                sss4 >> dummy >> x;
                ///B.set_Quantity(data3);

                getline(infile, line);
                stringstream sss5(line);
                sss5 >> dummy >> y;
                ///B.set_Price(data2);

                Buyer_Copy B(s1, s2, s3, x, y);

                ///cout << B << endl;

                S.temp.push_back(B);

            }

            getline(infile, line);
            stringstream ssss(line);
            ssss >> dummy >> data2;
            ///cout << data2 << endl;
            S.set_Total_Amount(data2);

        }

        Vec.push_back(S);
    }

    infile.close();

    ///cout << Vec[0] << endl;

    for(int i = 0; i < n; i++)
    {
        if(Nam == Vec[i].get_Buyer_Name())
        {
            cout << Vec[i] << endl;

            A:
            cout << "        ==========================" << endl;
            cout << "        || Press Y for Main Menu||" << endl;
            cout << "        ==========================" << endl;

            cout << "        ==========================" << endl;
            cout << "        || Press N for Exit     ||" << endl;
            cout << "        ==========================" << endl;

            char ch;
            cin >> ch;

            if(ch == 'Y' || ch == 'y')
            {
                main();
            }
            else if(ch == 'N' || ch == 'n')
            {
                exit(1);
            }
            else
            {
                cout << endl << "Wrong Selection !!!" << endl;

                goto A;
            }
        }
    }

    cout << endl << endl << "     NOT FOUND !!!" << endl;

    B:
    cout << "        ==========================" << endl;
    cout << "        || Press Y for Main Menu||" << endl;
    cout << "        ==========================" << endl;

    cout << "        ==========================" << endl;
    cout << "        || Press N for Exit     ||" << endl;
    cout << "        ==========================" << endl;

    char ch;
    cin >> ch;

    if(ch == 'Y' || ch == 'y')
    {
        main();
    }
    else if(ch == 'N' || ch == 'n')
    {
        exit(1);
    }
    else
    {
        cout << endl << "Wrong Selection !!!" << endl;

        goto B;
    }

}

void Options :: Search_by_Phone()
{
    system("PAUSE");
    system("cls");

    string Phn;
    cout << "Enter The Phone Number You Want To Search: ";
    cin >> ws;
    getline(cin, Phn);

    int n;
    n = Counter();
    ///int len = 0;
    vector <Seller_Copy> Vec;

    ifstream infile;
    infile.open("Seller_Copy.txt");
    string line, dummy, data1;
    double data2;
    int data3;

    while(infile)
    {
        Seller_Copy S;
        getline(infile, line);

        /***
        if(line == "    ==== 0 ====    ")
        {
            len++;
        }
        **/

        stringstream ss(line);
        ss >> dummy;

        if(dummy == "Name:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Buyer_Name(data1);
        }
        else if(dummy == "Phone:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Phone(data1);
        }
        else if(dummy == "Email:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Mail(data1);
        }
        else if(dummy == "Address:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Address(data1);
        }
        else if(dummy == "Product_Types:")
        {
            ss >> data3;
            ///cout << data3 << endl;
            S.set_n(data3);

            int x = data3;

            for(int i = 1; i <= x; i++)
            {
                string s1, s2, s3;
                int x;
                double y;

                getline(infile, line);
                stringstream sss1(line);
                sss1 >> dummy >> s1;
                ///B.set_Product_Id(data1);

                getline(infile, line);
                stringstream sss2(line);
                sss2 >> dummy >> s2;
                ///B.set_Product_Name(data1);

                getline(infile, line);
                stringstream sss3(line);
                sss3 >> dummy >> s3;
                ///B.set_Brand(data1);

                getline(infile, line);
                stringstream sss4(line);
                sss4 >> dummy >> x;
                ///B.set_Quantity(data3);

                getline(infile, line);
                stringstream sss5(line);
                sss5 >> dummy >> y;
                ///B.set_Price(data2);

                Buyer_Copy B(s1, s2, s3, x, y);

                ///cout << B << endl;

                S.temp.push_back(B);

            }

            getline(infile, line);
            stringstream ssss(line);
            ssss >> dummy >> data2;
            ///cout << data2 << endl;
            S.set_Total_Amount(data2);

        }

        Vec.push_back(S);
    }

    infile.close();

    for(int i = 0; i < n; i++)
    {
        if(Phn == Vec[i].get_Phone())
        {
            cout << Vec[i] << endl;

            A:
            cout << "        ==========================" << endl;
            cout << "        || Press Y for Main Menu||" << endl;
            cout << "        ==========================" << endl;

            cout << "        ==========================" << endl;
            cout << "        || Press N for Exit     ||" << endl;
            cout << "        ==========================" << endl;

            char ch;
            cin >> ch;

            if(ch == 'Y' || ch == 'y')
            {
                return;
            }
            else if(ch == 'N' || ch == 'n')
            {
                exit(1);
            }
            else
            {
                cout << endl << "Wrong Selection !!!" << endl;

                goto A;
            }
        }
    }

    cout << endl << endl << "     NOT FOUND !!!" << endl;

    B:
    cout << "        ==========================" << endl;
    cout << "        || Press Y for Main Menu||" << endl;
    cout << "        ==========================" << endl;

    cout << "        ==========================" << endl;
    cout << "        || Press N for Exit     ||" << endl;
    cout << "        ==========================" << endl;

    char ch;
    cin >> ch;

    if(ch == 'Y' || ch == 'y')
    {
        main();
    }
    else if(ch == 'N' || ch == 'n')
    {
        exit(1);
    }
    else
    {
        cout << endl << "Wrong Selection !!!" << endl;

        goto B;
    }

}

void Options :: Search_by_Email()
{
    system("PAUSE");
    system("cls");

    string Mail;
    cout << "Enter The Email You Want To Search: ";
    cin >> ws;
    getline(cin, Mail);

    int n;
    n = Counter();
    ///int len = 0;
    vector <Seller_Copy> Vec;

    ifstream infile;
    infile.open("Seller_Copy.txt");
    string line, dummy, data1;
    double data2;
    int data3;

    while(infile)
    {
        Seller_Copy S;
        getline(infile, line);

        /***
        if(line == "    ==== 0 ====    ")
        {
            len++;
        }
        **/

        stringstream ss(line);
        ss >> dummy;

        if(dummy == "Name:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Buyer_Name(data1);
        }
        else if(dummy == "Phone:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Phone(data1);
        }
        else if(dummy == "Email:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Mail(data1);
        }
        else if(dummy == "Address:")
        {
            ss >> data1;
            ///cout << data1 << endl;
            S.set_Address(data1);
        }
        else if(dummy == "Product_Types:")
        {
            ss >> data3;
            ///cout << data3 << endl;
            S.set_n(data3);

            int x = data3;

            for(int i = 1; i <= x; i++)
            {
                string s1, s2, s3;
                int x;
                double y;

                getline(infile, line);
                stringstream sss1(line);
                sss1 >> dummy >> s1;
                ///B.set_Product_Id(data1);

                getline(infile, line);
                stringstream sss2(line);
                sss2 >> dummy >> s2;
                ///B.set_Product_Name(data1);

                getline(infile, line);
                stringstream sss3(line);
                sss3 >> dummy >> s3;
                ///B.set_Brand(data1);

                getline(infile, line);
                stringstream sss4(line);
                sss4 >> dummy >> x;
                ///B.set_Quantity(data3);

                getline(infile, line);
                stringstream sss5(line);
                sss5 >> dummy >> y;
                ///B.set_Price(data2);

                Buyer_Copy B(s1, s2, s3, x, y);

                ///cout << B << endl;

                S.temp.push_back(B);

            }

            getline(infile, line);
            stringstream ssss(line);
            ssss >> dummy >> data2;
            ///cout << data2 << endl;
            S.set_Total_Amount(data2);

        }

        Vec.push_back(S);
    }

    infile.close();

    for(int i = 0; i < n; i++)
    {
        if(Mail == Vec[i].get_Mail())
        {
            cout << Vec[i] << endl;

            A:
            cout << "        ==========================" << endl;
            cout << "        || Press Y for Main Menu||" << endl;
            cout << "        ==========================" << endl;

            cout << "        ==========================" << endl;
            cout << "        || Press N for Exit     ||" << endl;
            cout << "        ==========================" << endl;

            char ch;
            cin >> ch;

            if(ch == 'Y' || ch == 'y')
            {
                return;
            }
            else if(ch == 'N' || ch == 'n')
            {
                exit(1);
            }
            else
            {
                cout << endl << "Wrong Selection !!!" << endl;

                goto A;
            }
        }
    }

    cout << endl << endl << "     NOT FOUND !!!" << endl;

    B:
    cout << "        ==========================" << endl;
    cout << "        || Press Y for Main Menu||" << endl;
    cout << "        ==========================" << endl;

    cout << "        ==========================" << endl;
    cout << "        || Press N for Exit     ||" << endl;
    cout << "        ==========================" << endl;

    char ch;
    cin >> ch;

    if(ch == 'Y' || ch == 'y')
    {
        main();
    }
    else if(ch == 'N' || ch == 'n')
    {
        exit(1);
    }
    else
    {
        cout << endl << "Wrong Selection !!!" << endl;

        goto B;
    }
}

void Options :: View()
{
    int n = Counter();
    Seller_Copy *S;
    ///S = Search();

    for(int i = 0; i < n; i++)
    {
        cout << S[i] << endl << endl;
    }
}

/**
void Options :: View()
{

}
**/

