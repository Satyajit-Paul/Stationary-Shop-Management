#include <bits/stdc++.h>
#include "Buyer_Copy.h"

using namespace std;

Buyer_Copy :: Buyer_Copy()
{
    //ctor
}

Buyer_Copy :: Buyer_Copy(string s1, string s2, string s3, int x, double y)
{
    Product_Id = s1;
    Product_Name = s2;
    Brand = s3;
    No_of_Product = x;
    Price = y;
    total = x * y;
}

Buyer_Copy :: ~Buyer_Copy()
{
    //dtor
}

void Buyer_Copy :: set_Product_Id(string s)
{
    Product_Id = s;
}

void Buyer_Copy :: set_Product_Name(string s)
{
    Product_Name = s;
}

void Buyer_Copy :: set_Brand(string s)
{
    Brand = s;
}

void Buyer_Copy :: set_Quantity(int n)
{
    No_of_Product = n;
}

void Buyer_Copy :: set_Price(double d)
{
    Price = d;
}

double Buyer_Copy :: get_total()
{
    return total;
}

void Buyer_Copy :: Write_to_List()
{
    ofstream fout;
    fout.open("Buyer_Copy.txt", ios :: app);


    fout << "Product_Id: " << Product_Id << endl;
    fout << "Product_Name: " << Product_Name << endl;
    fout << "Brand: " << Brand << endl;
    fout << "Quantity: " << No_of_Product << endl;
    fout << "Price: " << Price << endl;

    fout << "    ==== 0 ====    " << endl;

    fout.close();

}


void Buyer_Copy :: Write_to_List(ofstream &fout)
{
    fout << "Product_Id: " << Product_Id << endl;
    fout << "Product_Name: " << Product_Name << endl;
    fout << "Brand: " << Brand << endl;
    fout << "Quantity: " << No_of_Product << endl;
    fout << "Price: " << Price << endl;
}


istream & operator >> (istream &input, Buyer_Copy &B)
{
    cout << "Enter The Product Id: ";
    cin >> ws;
    getline(input, B.Product_Id);

    cout << "Enter The Product Name: ";
    getline(input, B.Product_Name);

    cout << "Enter The Brand of The Product: ";
    getline(input, B.Brand);

    cout << "Enter The Quantity of Product: ";
    input >> B.No_of_Product;

    cout << "Enter The Price of the Product: ";
    input >> B.Price;

    B.total = B.Price * B.No_of_Product;

    return input;

}

ostream & operator << (ostream &output, Buyer_Copy &B)
{
    output << setprecision(4);
    output << setiosflags(ios :: fixed);

    output << "Product_Id: " << B.Product_Id << endl;
    output << "Product_Name: " << B.Product_Name << endl;
    output << "Brand: " << B.Brand << endl;
    output << "Quantity: " << B.No_of_Product << endl;
    output << "Price: " << B.Price << endl;

    return output;
}

