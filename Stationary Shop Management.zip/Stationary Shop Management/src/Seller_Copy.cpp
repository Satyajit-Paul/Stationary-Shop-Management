#include <bits/stdc++.h>
#include "Seller_Copy.h"

using namespace std;

Seller_Copy :: Seller_Copy()
{
    //ctor
}

Seller_Copy :: Seller_Copy(int n)
{
    //ctor
    this->n = n;
}

Seller_Copy :: ~Seller_Copy()
{
    //dtor
}

void Seller_Copy :: set_n(int x)
{
    n = x;
}

void Seller_Copy :: set_Buyer_Name(string s)
{
    Buyer_Name = s;
}

string Seller_Copy :: get_Buyer_Name()
{
    return Buyer_Name;
}

void Seller_Copy :: set_Mail(string s)
{
    Email = s;
}

string Seller_Copy :: get_Mail()
{
    return Email;
}

void Seller_Copy :: set_Phone(string s)
{
    Phone = s;
}

string Seller_Copy :: get_Phone()
{
    return Phone;
}

void Seller_Copy :: set_Address(string s)
{
    Address = s;
}

void Seller_Copy ::set_Total_Amount(double d)
{
    Total_Amunt = d;
}

void Seller_Copy :: set_total()
{
    double sum = 0;
    for(int i = 0; i < n; i++)
    {
        sum += temp[i].get_total();
    }

    Total_Amunt = sum;
}

void Seller_Copy :: Write_to_History()
{
    ofstream fout;
    fout.open("Seller_Copy.txt", ios :: app);

    set_total();

    ///fout << "Serial: " << Serial_Number << endl;
    fout << "Name: " << Buyer_Name << endl;
    fout << "Phone: " << Phone << endl;
    fout << "Email: " << Email << endl;
    fout << "Address: " << Address << endl;
    fout << "Product_Types: " << n << endl;


    for(int i = 0; i < n; i++)
    {
        temp[i].Write_to_List();
        temp[i].Write_to_List(fout);
    }


    fout << "Total_Amount: " << Total_Amunt << endl;
    fout << "    ==== 0 ====    " << endl;

    fout.close();

}

istream & operator >> (istream &input, Seller_Copy &S)
{
    cout << "Enter The Name of The Buyer: ";
    cin >> ws;
    getline(input, S.Buyer_Name);

    cout << "Enter The Phone Number of The Buyer: ";
    getline(input, S.Phone);

    cout << "Enter The Address of The Buyer: ";
    getline(input, S.Address);

    cout << "Enter The Email of The Buyer: ";
    getline(input, S.Email);

    for(int i = 0; i < S.n; i++)
    {
        Buyer_Copy Space;
        cin >> Space;
        Space.Write_to_List();
        S.temp.push_back(Space);
    }

    return input;

}

ostream & operator << (ostream &output, Seller_Copy &S)
{
    output << setprecision(4);
    output << setiosflags(ios :: fixed);

    output << "Name: " << S.Buyer_Name << endl;
    output << "Phone: " << S.Phone << endl;
    output << "Email: " << S.Email << endl;
    output << "Address: " << S.Address << endl;
    output << "Product_Types: " << S.n << endl;

    for(int i = 0; i < S.n; i++)
    {
        cout << S.temp[i];
    }

    return output;
}
