#include <bits/stdc++.h>
#include "Buyer_Copy.h"
#include "Seller_Copy.h"
#include "Options.h"

using namespace std;

int main()
{
    cout << "           =======================" << endl;
    cout << "           || Press 1 for Insert||" << endl;
    cout << "           =======================" << endl;

    cout << "           =======================" << endl;
    cout << "           || Press 2 for Update||" << endl;
    cout << "           =======================" << endl;

    cout << "           =======================" << endl;
    cout << "           || Press 3 for Search||" << endl;
    cout << "           =======================" << endl;

    cout << "           =======================" << endl;
    cout << "           || Press 4 for View  ||" << endl;
    cout << "           =======================" << endl;

    cout << "           =======================" << endl;
    cout << "           || Press 5 for Exit  ||" << endl;
    cout << "           =======================" << endl;

    A:
    int sat;
    cout << "Chose an Options: ";
    cin >> sat;

    if(sat == 1)
    {
        int quantity;
        cout << "Enter The Number Of Product: ";
        cin >> quantity;

        Seller_Copy S(quantity);

        cin >> S;
        S.Write_to_History();
        cout << S;


        B:
        cout << "        ==========================" << endl;
        cout << "        || Press Y for Main Menu||" << endl;
        cout << "        ==========================" << endl;

        cout << "        ==========================" << endl;
        cout << "        || Press N for Exit     ||" << endl;
        cout << "        ==========================" << endl;

        char ch;
        cin >> ch;

        if(ch == 'Y' || ch == 'y')
        {
            main();
        }
        else if(ch == 'N' || ch == 'n')
        {
            exit(1);
        }
        else
        {
            cout << endl << "Wrong Selection !!!" << endl;

            goto B;
        }
    }
    else if(sat == 2)
    {

    }
    else if(sat == 3)
    {
        Options OP;


        C:
        cout << "       ===========================" << endl;
        cout << "       || Press 1 to Search Name||" << endl;
        cout << "       ===========================" << endl;

        cout << "       ===========================" << endl;
        cout << "       || Press 2 to Search Phone||" << endl;
        cout << "       ===========================" << endl;

        cout << "       ===========================" << endl;
        cout << "       ||Press 3 to Search Email||" << endl;
        cout << "       ===========================" << endl;

        int x;
        cout << "Chose An Option: ";

        cin >> x;

        if(x == 1)
        {
            OP.Search_by_Name();
        }
        else if(x == 2)
        {
            OP.Search_by_Phone();
        }
        else if(x == 3)
        {
            OP.Search_by_Email();
        }
        else
        {
            cout << "Wrong Selection !!!" << endl;
            goto C;
        }

    }
    else if(sat == 4)
    {
        Options Op;
        Op.View();
    }
    else if(sat == 5)
    {
        return 0;
    }
    else
    {
        cout << "Wrong Selection !!!" << endl;
        goto A;
    }

    return 0;
}
